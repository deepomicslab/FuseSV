# LocalHaplotypeSolver

Requires Python2.7 and PuLP package for linear programming.

```bash
python -m pip install pulp
```
