#verion=v1.2
#Wenlong JIA, 2020-09-12

category=null;
sample=null;
st_step=1;
ed_step=3;
randtm=0;
# Parsing arguments
usage="Usage: `basename $0` -c <category> -s <sample> -p <st_step> -e <ed_step> -t <randtm[0]>"
while getopts 'c:p:e:t:s:h' OPT; do
    case $OPT in
        h)
            echo $usage; exit;;
        c)
            category=$OPTARG;;
        p)
            st_step=$OPTARG;;
        e)
            ed_step=$OPTARG;;
        s)
            sample=$OPTARG;;
        t)
            randtm=$OPTARG;;
        ?)
            echo $usage; exit;;
    esac
done

if [ $category = "null" ] || [ $sample = "null" ]; then
  echo $usage; exit 1;
fi

whole_dir=$PWD;
pm_dir=$whole_dir/programs/Perl_Modules;
if [ ! -e $pm_dir ]; then
  echo "cannot find perl module folder: $pm_dir";
  exit 1;
fi
sample_dir=$whole_dir/$category/$sample;
if [ ! -e $sample_dir ]; then
  echo "cannot find sample folder: $sample_dir";
  exit 1;
fi

source $whole_dir/setting.sh;

cd $sample_dir/LocalHapWorkspace;

if [ $st_step -le 1 ] && [ $ed_step -ge 1 ]; then
  if [ -e ../bam ]; then
    echo -e "\n#-------- step 01 get_segCN --------#\n";
    bash $whole_dir/bin/step01_cmd.sh \
      -f $FuseSV \
      -s $SAMtools \
      -t $tabix \
      -p $tpsl_bgz \
      -m $pm_dir
  else
    echo -e "\nskip step 01, no bam file\n";
  fi;
  sleep 1;
fi

if [ $st_step -le 2 ] && [ $ed_step -ge 2 ]; then
  echo -e "\n#-------- step 02 get_ucyc --------#\n";
  bash $whole_dir/bin/step02_cmd.sh \
    -f $FuseSV \
    -l $LocalHaplotypeSolver \
    -m $pm_dir \
    -s $sample
  sleep 1;
fi

if [ $st_step -le 3 ] && [ $ed_step -ge 3 ]; then
  echo -e "\n#-------- step 03 get_LGM --------#\n";
  bash $whole_dir/bin/step03_cmd.sh \
    -f $FuseSV \
    -m $pm_dir \
    -s $sample \
    -t $randtm
  sleep 1;
fi

