< Basic Description >
This folder contains software and sample data used in oncovirus integrations
local genomic map (LGM) construction analysis.

< Copyrights >
Software of FuseSV and LocalHaplotypeSolver provided are designed and
developed by the DeepOmics team from City University of Hong Kong (CityU-HK,
co-authers, Wenlong Jia, Chang Xu, and Shuaicheng Li).

< Contents >
sub-folders in this sharing folder.
1) 'programs' folder contains:
    a) FuseSV, developed by Wenlong Jia.
    b) LocalHaplotypeSolver, developed by Wenlong Jia and Chang Xu.
    c) Other modules and software supporting the data processing.
   Note that,
    > all software are tested on Linux systems.
    > FuseSV
      please check https://github.com/deepomicslab/FuseSV
    > LocalHaplotypeSolver requires PuLP package
      please check https://github.com/deepomicslab/LocalHaplotypeSolver

2) 'bin' folder contains shell files of three steps in LGM analysis.

3) 'simu_shortReads' folder contains data based on short-reads simulated by 'wgsim'.

4) 'simu_longReads'  folder contains data based on  long-reads simulated by 'pbsim2'.
    In each sample folder,
    > sub-folder 'pbsim2' stores simulated long-reads (fastq format) and details.
    > sub-folder 'jr_count' stores long-reads covering each junction in LGM.

5) 'CC_NG_2015' folder contains:
    Four cervical cancer samples whose HPV integration local genomic maps
    have been reported in previous study: T4931, T6050, SIHA, and HELA.
    In each sample folder,
    > sub-folder 'jr_count' stores reads covering each junction in LGM.

6) 'HPV_GR_2014' folder contains:
    Two HNSCC cell lines whose HPV integration local genomic maps
    have been reported in published paper: UM-SCC-47 and UPCI-SCC090.
    In each sample folder,
    > sub-folder 'jr_count' stores reads covering each junction in LGM.

7) 'HCC_NG_2012' folder contains:
    Six HCC cancer samples with HBV integrations: 101T, 13T, 182T, 260T, 261T, 62T
    In each sample folder,
    > sub-folder 'jr_count' stores reads covering each junction in LGM.

8) 'MeerKat_2013' folder contains:
    One GBM sample with complex SVs at CDK4 gene locus, and the local genomic map
    has been reported in published paper: GBM0152

< About How to Process the Data >
1) each sample folder has 'LocalHapWorkspace' sub-folder that stores all works of LGM.

2) In 'LocalHapWorkspace' folder, there are three sub-folders corresponding
   to three steps:
   > step01_segCN
   > step02_ucyc
   > step03_LGM

3) use 'process.sh' to run analysis of LGM.
   Usage: process.sh -c <category> -s <sample> -p <st_step> -e <ed_step> -t <randtm[0]>
   INSTANCE:
   a) SIHA sample, run all steps, with simplest LGM mode
      bash process.sh -c CC_NG_2015 -s SIHA
   b) HELA sample, run all steps, with random LGM mode (random time = 100)
      bash process.sh -c CC_NG_2015 -s HELA -t 100
   c) 62T sample (chr19), run step02 only
      bash process.sh -c HCC_NG_2012 -s 62T-chr19 -p 2 -e 2
   d) GBM0152 sample, run step03 only (with step01 and step02 already done before)
      bash process.sh -c MeerKat_2013 -s GBM0152 -p 3 -e 3 -t 1000

4) Due to the large file size, we don't provide bam file for each sample in this folder.
   Note:
   a) The step01 will not run without bam file.
      The results have been prepared in the step01_segCN sub-folder.

5) When the process.sh is running, logs will be printed on screen,
   and the results will be stored in relevant step-folder.
   Take SIHA as an example.
   > in step01_segCN, the result files (prepared) are:
     a) SIHA.InputForLocalHapAlgorithm.txt
     b) SIHA.xxx.svg
        You may find two 'InputForLocalHapAlgorithm.txt' files. The one with
        longer name is the initial output of step01_segCN. And after updating the
        '_please_fix_me_' field with results from Patchwork, we get the one with
        a shorter name, which is the input of the second step.
   > in step02_ucyc, the result is
     a) SIHA.LOH.ucyc.txt
        It contains the basic contigs that form the LGM. We call them unit-cycle (UCYC).
        This file is the input of the third step.
   > in step03_LGM, the result is
     a) SIHA.LOH.LGM.randtm_0.txt
        This is the final result showing LGM of HPV integrations. The
        result corresponds to the 'Simplest LGM' report in our paper.
     b) If non-zero randtm is set, e.g., 100, the file name will be 'SIHA.LOH.LGM.randtm_100.txt'

Wenlong Jia
wenlongkxm@gmail.com
City University of Hong Kong
2021-07-17
