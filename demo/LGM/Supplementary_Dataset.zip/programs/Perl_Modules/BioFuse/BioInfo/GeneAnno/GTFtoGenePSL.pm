package BioFuse::BioInfo::GeneAnno::GTFtoGenePSL;

use strict;
use warnings;
use Getopt::Long;
use BioFuse::Util::Log qw/ warn_and_exit /;
use BioFuse::Util::Sys qw/ file_exist /;
use BioFuse::LoadOn;
use BioFuse::BioInfo::Objects::GeneAnno::GTF_OB;

require Exporter;

#----- systemic variables -----
our (@ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
my ($VERSION, $DATE, $AUTHOR, $EMAIL, $MODULE_NAME);
@ISA = qw(Exporter);
@EXPORT = qw/
              GTFtoGenePSL
            /;
@EXPORT_OK = qw();
%EXPORT_TAGS = ( DEFAULT => [qw()],
                 OTHER   => [qw()]);

$MODULE_NAME = 'BioFuse::BioInfo::GeneAnno::GTFtoGenePSL';
#----- version --------
$VERSION = "0.83";
$DATE = '2019-05-04';

#----- author -----
$AUTHOR = 'Wenlong Jia';
$EMAIL = 'wenlongkxm@gmail.com';

#--------- functions in this pm --------#
my @functoion_list = qw/
                        return_HELP_INFO
                        Load_moduleVar_to_pubVarPool
                        Get_Cmd_Options
                        para_alert
                        GTFtoGenePSL
                     /;

#--- return HELP_INFO ---
sub return_HELP_INFO{
 return "
     Usage:   perl $V_Href->{MainName} get_gpsl <[Options]>

     Options:
         -g   [s]  gtf file. <required>
         -o   [s]  gene PSL file to output. <required>
         -rft [s]  TABLE-separated list of refseg symbols relationship. [optional]
                    NOTE: Generaly, the ref_seg symbols in GTP file (normally, the first column) is different from 
                          that in reference file (the '-f' parameter). So, you should specify the corresponding relationship
                          of refseg symbols between GTF file and reference file.
                          Format:  refseg_symbol_in_gtf  refseg_symbol_in_reference
                          e.g.,  10  chr10
         -sor [s]  select the source of gtf, can be used in multiple times. Default to accept all sources.
                    NOTE: From v75, ensembl provides the source_info stored by 'gene_source' tag.
                          It will accept the transcript whose gene_source tag contains your input.
                          For instance, once you input 'havana', it will accept both 'havana' and 'ensembl_havana'.
                                        if you input 'ensembl', it means both 'ensembl' and 'ensembl_havana' will be accepted.
         -cbd [s]  the cytoBand file. [optional]
                    e.g., Download human file from UCSC:
                       For hg19:  http://hgdownload.cse.ucsc.edu/goldenPath/hg19/database/cytoBand.txt.gz
                       For hg38:  http://hgdownload.cse.ucsc.edu/goldenPath/hg38/database/cytoBand.txt.gz
         -h        show this help

     Version:
        $VERSION at $DATE

     Author:
        $AUTHOR ($EMAIL)
 \n";
}

#--- load variant of this module to public variant (V_Href in LoadOn.pm) ---
sub Load_moduleVar_to_pubVarPool{
    $V_Href->{ $_->[0] } = $_->[1] for
        map {
            if( !exists $V_Href->{$_->[0]} ){
                ( $_ );
            }
            else{
                warn_and_exit "<ERROR>\tkey $_->[0] is already in V_Href!\n";
            }
        }
        (
            # input/output
            ## use 'psl' in BioFuse::LoadOn
            ## use 'gtf' in BioFuse::LoadOn
            ## use 'cytoBand_file' in BioFuse::LoadOn
            [ refseg_transform_list => undef ],
            # option
            [ gtf_source => [] ],

            # intermediate variants
            [ GTF_gene => {} ],
            [ cytoBand => {} ],
            [ _refseg_transform => {} ],

            # list to abs-path
            [ ToAbsPath_Aref => [ ['psl'],
                                  ['gtf']  ] ]
        );
}

#--- get options from command line ---
sub Get_Cmd_Options{
    # get options
    GetOptions(
        # input/output
        "-o:s"  => \$V_Href->{psl},
        "-g:s"  => \$V_Href->{gtf},
        "-rft:s"=> \$V_Href->{refseg_transform_list},
        "-cbd:s"=> \$V_Href->{cytoBand_file},
        # options
        "-sor:s"=> \@{$V_Href->{gtf_source}},
        # help
        "-h|help"   => \$V_Href->{HELP},
        # for debug
        "-debug"    => \$V_Href->{in_debug} # hidden option
    );
}

#--- test para and alert ---
sub para_alert{
    return  (   $V_Href->{HELP}
             || !file_exist(filePath=>$V_Href->{gtf})
             || !defined $V_Href->{psl}
            );
}

#--- get gene PSL file from GTF file---
sub GTFtoGenePSL{
    # gtf object
    my $gtf = BioFuse::BioInfo::Objects::GeneAnno::GTF_OB->new(filePath => $V_Href->{gtf});
    # read GTF
    $gtf->load_GTF( refseg_transform_list => $V_Href->{refseg_transform_list},
                    gtf_source => $V_Href->{gtf_source},
                    cytoBand_file => $V_Href->{cytoBand_file}
                  );
    # output gene psl
    $gtf->create_gene_PSL(gPSLpath => $V_Href->{psl});
}

#--- 
1; ## tell the perl script the successful access of this module.
