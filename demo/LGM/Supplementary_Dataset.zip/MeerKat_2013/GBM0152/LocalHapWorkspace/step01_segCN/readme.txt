1) The junction split-reads count is simulated.
2) The H37->H2 junction is set as zero split-reads, to break the ecDNA circle to get linear LGM structure.
